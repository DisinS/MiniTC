﻿using System.Collections.Generic;
using System.IO;
using System.Windows.Input;

namespace MiniTC.ViewModel
{
    internal class PanelVM : VMBase
    {
        public PanelVM() => GetDrives();
        
        #region Własności
        private string currentDrive;
        private string[] drives;
        private string currentPath;
        private string selectedDirectory;
        private List<string> directoryContent;

        public string CurrentDrive
        {
            get => currentDrive;
            set
            {
                try
                {
                    currentDrive = value;
                    onPropertyChanged(nameof(CurrentDrive));
                    ChangeDrive();
                }
                catch { }
            }
        }
        public string[] Drives
        {
            get => drives;
            set
            {
                drives = value;
                onPropertyChanged(nameof(Drives));
            }
        }
        public string CurrentPath
        {
            get => currentPath; 
            set 
            {
                currentPath = value;
                onPropertyChanged(nameof(CurrentPath));
                UpdateListBox();
            }
        }
        public string SelectedDirectory
        {
            get => selectedDirectory;
            set
            {
                selectedDirectory = value;
                onPropertyChanged(nameof(SelectedDirectory));
            }
        }
        public List<string> DirectoryContent
        {
            get => directoryContent; 
            set 
            { 
                directoryContent = value; 
                onPropertyChanged(nameof(DirectoryContent)); 
            }
        }
        #endregion

        #region Polecenia
        private ICommand _changedirectory = null;
        public ICommand ChangeDirectory
        {
            get
            {
                if (_changedirectory == null)
                {
                    _changedirectory = new RelayCommand(
                        arg =>
                        {
                            if (selectedDirectory.Equals("..")) //get back
                                CurrentPath = Directory.GetParent(CurrentPath).FullName;
                            else //move forward
                            {
                                if (CurrentPath.EndsWith("\\"))
                                    CurrentPath += selectedDirectory.Replace("<D> ", "");
                                else
                                    CurrentPath += "\\" + selectedDirectory.Replace("<D> ", "");
                            }
                        },
                        arg =>
                        {
                            if (selectedDirectory == "..") //get back
                                return true;
                            if (selectedDirectory != null && selectedDirectory.Contains("<D>")) //move forward
                                return true;

                            return false;
                        }
                        );
                }
                return _changedirectory;
            }
        }
        #endregion

        #region Metody
        private void GetDrives() => Drives = Directory.GetLogicalDrives();
        private void ChangeDrive() => CurrentPath = currentDrive;
        private void UpdateListBox()
        {
            List<string> Content = new List<string>();

            try
            {

                string[] files = Directory.GetFiles(CurrentPath);
                string[] dirs = Directory.GetDirectories(CurrentPath);
                DirectoryInfo parentFile = Directory.GetParent(CurrentPath);

                if (parentFile != null)
                    Content.Add("..");
                foreach (string dir in dirs)
                    if (!(new DirectoryInfo(dir).Attributes.HasFlag(FileAttributes.Hidden)))
                        Content.Add("<D> " + Path.GetFileName(dir));
                foreach (string file in files)
                    if (!(new DirectoryInfo(file).Attributes.HasFlag(FileAttributes.Hidden)))
                        Content.Add(Path.GetFileName(file));
            }
            catch { }

            DirectoryContent = Content;
        }
        #endregion
    }
}