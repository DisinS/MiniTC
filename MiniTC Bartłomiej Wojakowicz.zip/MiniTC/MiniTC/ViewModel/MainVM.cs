﻿using System.Windows.Input;
using System.IO;

namespace MiniTC.ViewModel
{
    internal class MainVM : VMBase
    {
        public MainVM()
        {
            Left = new PanelVM();
            Right = new PanelVM();
        }

        #region Własności
        private PanelVM left;
        public PanelVM Left
        {
            get => left;
            set
            {
                left = value;
                onPropertyChanged(nameof(Left));
            }
        }

        private PanelVM right;
        public PanelVM Right
        {
            get => right;
            set
            {
                right = value;
                onPropertyChanged(nameof(Right));
            }
        }
        #endregion

        #region Polecenia
        private ICommand copyFile = null;
        public ICommand CopyFile
        {
            get
            {
                if (copyFile == null)
                    copyFile = new RelayCommand(
                        arg => Copy(), 
                        arg => IsCopyPossible()
                        );
                return copyFile;
            }
        }
        #endregion

        #region Metody

        private void Copy()
        {
            string filePath, directoryPath, fileName;
            if (Left.SelectedDirectory != null) //copy from left to right
            {
                filePath = Left.CurrentPath + "\\" + Left.SelectedDirectory.Trim();
                directoryPath = Right.CurrentPath;
                fileName = Path.GetFileName(filePath);
            }
            else //copy from right to left
            {
                filePath = Right.CurrentPath + "\\" + Right.SelectedDirectory.Trim();
                directoryPath = Left.CurrentPath;
                fileName = Path.GetFileName(filePath);
            }
            File.Copy(filePath, directoryPath + "\\" + fileName);
            Left.CurrentPath = Left.CurrentPath; //update left panel
            Right.CurrentPath = Right.CurrentPath; //update right panel
        }

        private bool IsCopyPossible()
        {
            //Copy is not possilble because of the same names of files in panels
            if (Right.SelectedDirectory != null && Left.DirectoryContent != null && Left.DirectoryContent.Contains(Right.SelectedDirectory))
                return false;
            if (Left.SelectedDirectory != null && Right.DirectoryContent != null && Right.DirectoryContent.Contains(Left.SelectedDirectory))
                return false;

            //Check possibility of copy from left panel to right
            if (Left.SelectedDirectory != null && !Left.SelectedDirectory.Contains("<D>") 
                && Left.SelectedDirectory != ".." && Right.CurrentPath != null) 
                return true;

            //Check possibility of copy from right panel to left
            if (Right.SelectedDirectory != null && !Right.SelectedDirectory.Contains("<D>")
                && Right.SelectedDirectory != ".." && Left.CurrentPath != null)
                    return true;

            return false;
        }
        #endregion
    }
}