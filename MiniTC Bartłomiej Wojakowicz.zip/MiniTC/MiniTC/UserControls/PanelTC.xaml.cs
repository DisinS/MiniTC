﻿using System.Windows;
using System.Windows.Controls;
using System.Collections.Generic;
using System.Windows.Input;

namespace MiniTC.UserControls
{
    public partial class PanelTC : UserControl
    {

        public PanelTC()
        {
            InitializeComponent();
        }

        #region Własności zależne

        private static readonly DependencyProperty DoubleClickCommandProperty =
            DependencyProperty.Register("DoubleClickCommand", typeof(ICommand), typeof(PanelTC),
                new FrameworkPropertyMetadata(null));

        private static readonly DependencyProperty CurrentPathProperty =
            DependencyProperty.Register("CurrentPath", typeof(string), typeof(PanelTC),
                new FrameworkPropertyMetadata(null));

        private static readonly DependencyProperty CurrentDriveProperty =
            DependencyProperty.Register("CurrentDrive", typeof(string), typeof(PanelTC),
                new FrameworkPropertyMetadata(null));

        private static readonly DependencyProperty DrivesProperty =
            DependencyProperty.Register("Drives", typeof(string[]), typeof(PanelTC),
                new FrameworkPropertyMetadata(null));

        private static readonly DependencyProperty DirectoryContentProperty =
            DependencyProperty.Register("DirectoryContent", typeof(List<string>), typeof(PanelTC),
                new FrameworkPropertyMetadata(null));

        private static readonly DependencyProperty SelectedDirectoryProperty =
            DependencyProperty.Register("SelectedDirectory", typeof(string), typeof(PanelTC),
                new FrameworkPropertyMetadata(null));

        #endregion

        #region Polecenia
        public ICommand DoubleClickCommand
        {
            get => (ICommand)GetValue(DoubleClickCommandProperty);
            set => SetValue(DoubleClickCommandProperty, value);
        }
        #endregion

        #region Interfejs publiczny
        public string CurrentPath
        {
            get => (string)GetValue(CurrentPathProperty); 
            set => SetValue(CurrentPathProperty, value); 
        }
        public string CurrentDrive
        {
            get => (string)GetValue(CurrentDriveProperty); 
            set => SetValue(CurrentDriveProperty, value); 
        }
        public string[] Drives
        {
            get => (string[])GetValue(DrivesProperty); 
            set => SetValue(DrivesProperty, value); 
        }
        public List<string> DirectoryContent
        {
            get => (List<string>)GetValue(DirectoryContentProperty); 
            set => SetValue(DirectoryContentProperty, value); 
        }
        public string SelectedDirectory
        {
            get => (string)GetValue(SelectedDirectoryProperty); 
            set => SetValue(SelectedDirectoryProperty, value); 
        }
        #endregion
    }
}